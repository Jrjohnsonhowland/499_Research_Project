gem "parallel"



require 'parallel'
require 'rbconfig'
require 'parallel/version'
require 'parallel/processor_count'
require 'etc'

# -------------------------------------------------------------------------------------
# 			PARALLEL GEM DOES NOT FUNCTION PROPERLY IN WINDOWS USE LINUX
# ---------------------------------------------------------------------------------------

class Mapreduce






end

file = File.open("Frankenstein.txt") # change directory here
book = file.read.split

nextStep = Parallel.map(book, in_processes: 8) { |element| element.downcase } # Mapping function

r = nextStep.inject(Hash.new(0)) {|hash,word| hash[word] += 1; hash }	#reduce function P1

r.flatten # Reduce P2

timer = Process.clock_gettime(Process::CLOCK_MONOTONIC)
timer = timer / (24 * 60 * 60.0)

File.open('RubyTimes.txt', 'a') do
    |f| f.write(timer, "\n")
end

puts r

puts t