#pragma once

#include <ppl.h>
#include <algorithm>
#include <iostream>
#include <string>
#include <vector>
#include <numeric>
#include <unordered_map>
#include <windows.h>

using namespace concurrency;
using namespace std;



struct ReduceFunc : binary_function<unordered_map<string, size_t>,
	unordered_map<string, size_t>, unordered_map<string, size_t>>
{
	unordered_map<string, size_t> operator() (
		const unordered_map<string, size_t>& x,
		const unordered_map<string, size_t>& y) const
	{
		unordered_map<string, size_t> ret(x);
		for_each(begin(y), end(y), [&ret](const pair<string, size_t>& pr) {
			auto key = pr.first;
			auto val = pr.second;	// Don't change to OMP for each Breaks
			ret[key] += val;
			});
		return ret;
	}
};