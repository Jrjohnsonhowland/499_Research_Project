
#include <ppl.h>
#include <algorithm>
#include <iostream>
#include <string>
#include <vector>
#include <numeric>
#include <unordered_map>
#include <windows.h>
#include <fstream>
#include "Mapper.h"
#include "Reducer.h"
#include "tToVector.h"
#include <assert.h>
#include <sstream>
#include <locale>
#include <codecvt>
#include <chrono>
#include <omp.h>







using namespace concurrency;
using namespace std;



int main()
{
    string loc = "Frankenstein.txt";            // Change DIR here
    // string loc2 = "File 2 here";             // Uncomment this to use multiple documents
    vector<string> Hold = loadFile(loc);
   
    std::vector<std::string> Hold2;

    // Hold2 = loadFile(loc2);                  // Uncomment this to use multiple documents



    vector<vector<string>> v{ Hold, Hold2 };

    vector<unordered_map<string, size_t>> map(v.size());
    auto start = std::chrono::high_resolution_clock::now();
    // The Map operation
    parallel_transform(begin(v), end(v), begin(map), Mapper());

   //  The Reduce operation 
    unordered_map<string, size_t> result = parallel_reduce(
        begin(map), end(map), unordered_map<string, size_t>(), ReduceFunc());

    auto t2 = std::chrono::high_resolution_clock::now();

    std::cout << "time taken (ms)" << std::chrono::duration_cast<std::chrono::milliseconds>(t2 - start).count() << "\n";
                                                                                                                                        //log time
    ofstream Record;
    Record.open("CPPtimes.txt", std::ios_base::app);
    Record << "Run Time(ms): " << std::chrono::duration_cast<std::chrono::milliseconds>(t2 - start).count() << "\n";


}

