#pragma once

#include <ppl.h>
#include <algorithm>
#include <iostream>
#include <string>
#include <vector>
#include <numeric>
#include <unordered_map>
#include <windows.h>
#include <omp.h>




using namespace concurrency;
using namespace std;

#define OMP_NUM_THREADS = 8

class Mapper
{

public:
	unordered_map<string, size_t> operator() (vector<string>& elements) const
	{
		const size_t n = std::distance(begin(elements), end(elements));

		unordered_map<string, size_t> m;


		#pragma omp parallel 
		{
			#pragma omp single
			{
				for (size_t i = 0; i < n; i++)
					
				{
					#pragma omp task
					{
						auto& elem = *(begin(elements) + i);
						m[elem]++;
					};
				}
				

			}
		}
		return m;
	}

};

