#include <ppl.h>
#include <algorithm>
#include <iostream>
#include <string>
#include <vector>
#include <numeric>
#include <unordered_map>
#include <windows.h>
#include <fstream>
#include <assert.h>



std::vector<std::string> loadFile(std::string fileName) {
    std::ifstream file(fileName);
    assert(file);

    std::vector<std::string> fileContents;
    std::copy(std::istream_iterator<std::string>(file),
        std::istream_iterator<std::string>(),
        std::back_inserter(fileContents));

    return fileContents;
}

