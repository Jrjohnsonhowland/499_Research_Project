import collections
import itertools
import multiprocessing


class SimpleMapReduce(object):

    def __init__(self, map_func, reduce_func, num_workers=8):

        self.map_func = map_func
        self.reduce_func = reduce_func                      # takes input data and returns a set of mapped values
        self.pool = multiprocessing.Pool(num_workers)

    def partition(self, mapped_values):
        partitioned_data = collections.defaultdict(list)
        for key, value in mapped_values:                    # takes mapped values and returns a set of key, value tuples
            partitioned_data[key].append(value)
        return partitioned_data.items()

    def __call__(self, inputs, chunksize=1):
        map_responses = self.pool.map(self.map_func, inputs, chunksize=chunksize)
        partitioned_data = self.partition(itertools.chain(*map_responses))      # takes tuple and reduces data
        reduced_values = self.pool.map(self.reduce_func, partitioned_data)
        return reduced_values
