import multiprocessing
import string
import time
import logging
import SimpMapreduce
import stopwatch

logging.basicConfig(level=logging.DEBUG)

# ___________________________________________________________________________________________________________
source_text = open("Frankenstein.txt", "r", encoding="utf8")
source_list = [line.split(' ') for line in source_text.readlines()]
hold_one = []
for sublist in source_list:
    for item in sublist:
        hold_one.append(item)
excluded = ['\n', '\\n']
hold_two = []
hold_one = list(filter(None, hold_one))  # text import and clean-up section

for item in hold_one:
    clean = True
    for exclude in excluded:
        if item.find(exclude) != -1:
            clean = False
            break
    if clean:
        hold_two.append(item)

with open('Cleaned.txt', 'w') as filehandle:
    for listitem in hold_two:
        filehandle.write('%s\n' % listitem)


def file_to_words(filename):            # Process word doc further
    STOP_WORDS = {'(', ')', ','}
    TR = str.maketrans(string.punctuation, ' ' * len(string.punctuation))

    print(multiprocessing.current_process().name, 'reading', filename)
    output = []

    with open(filename, 'rt') as f:
        for line in f:
            if line.lstrip().startswith('..'):  # Skip rst comment lines
                continue
            line = line.translate(TR)  # Strip punctuation
            for word in line.split():
                word = word.lower()
                if word.isalpha() and word not in STOP_WORDS:
                    output.append((word, 1))
    return output


def count_words(item):
    word, occurances = item
    return word, sum(occurances)


if __name__ == '__main__':
    import operator
    import glob

    input_files = glob.glob('Cleaned.txt')

    timer = stopwatch.Stopwatch()
    timer.start()
    mapper = SimpMapreduce.SimpleMapReduce(file_to_words, count_words)

    word_counts = mapper(input_files)
    word_counts.sort(key=operator.itemgetter(1))
    word_counts.reverse()

    timer.stop()
    Record = open("Times.txt", 'a')
    Record.write(str(timer) + '\n')
    Record.close()
    clear = open("Cleaned.txt", 'a')
    clear.truncate(0)

    print('TIME :' + str(timer))
    longest = max(len(word) for word, count in word_counts)
    for word, count in word_counts:
        print('%-*s: %5s' % (longest + 1, word, count))