/**
 * 
 */
/**
 * @author I'm Blue 2.0
 *
 */
module javaMapReduce {
	requires java.base;
}