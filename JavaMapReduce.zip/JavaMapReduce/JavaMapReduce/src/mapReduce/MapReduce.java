/**
 * 
 */
package mapReduce;

import java.io.BufferedWriter;

/**
 * @author I'm Blue 2.0
 *
 */


import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class MapReduce {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		
//_______________________________________________________________________________________________________________________________________
		String token1 = " ";
		
		File file = new File("Frankenstein.txt");
		File timesJava = new File("TimesJava.txt");

	    Scanner inFile1 = new Scanner(file).useDelimiter(" |\\n|,");

	    List<String> shelly = new ArrayList<String>();

	    // while loop
	    while (inFile1.hasNext()) {
	      token1 = inFile1.next();						//This section takes the text file, cleans it, passes it to an array then to a stream
	      shelly.add(token1);
	    }
	    inFile1.close();

	    String[] shellyArray = shelly.toArray(new String[0]);

	   // for (String s : shellyArray) {
	    //    System.out.println(s);
	    //}
		
	    Stream<String> maryStream = Arrays.stream(shellyArray);
//___________________________________________________________________________________________________________________________________________
	    Instant start = Instant.now();
	    
	    Stream<String> mappedStream = maryStream.parallel().map(s -> s.toUpperCase()); //make all text uniform
	    
	    //collecting the key, value pairs
	    Map<String, Long> mappCount = mappedStream.parallel().collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
	    
	    Map<String, Long> mappCountSorted = new LinkedHashMap<>();
	    
	    mappCount.entrySet().stream().sorted(Map.Entry.comparingByValue())	//sort pairs
	    .forEachOrdered(x -> mappCountSorted.put(x.getKey(), x.getValue()));
	    
	    Instant end = Instant.now();
	    
	    FileWriter fileWriter = new FileWriter(timesJava, true); //Set true for append mode
	    PrintWriter printWriter = new PrintWriter(fileWriter);
	    printWriter.println(Duration.between(start, end).toString());  //New line
	    printWriter.close();
                
	    System.out.println(mappCount);	// print final count
	    System.out.println(Duration.between(start, end).toString());

}}
