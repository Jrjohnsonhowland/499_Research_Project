﻿/////////////////////////////////////////////////////////////////////////////////
///             Original version Written by Jake Drew                         ///
///             © 2013 jakemdrew.com. All rights reserved.                    ///
///             YT:https://www.youtube.com/watch?v=_zf2Q153KG8                ///
///         licensed under The GNU General Public License                     ///
///---------------------------------------------------------------------------///
///     My Modified version addes a logging system and automaticly adjusts    ///
///     the block size to reflect the current systems processor count.        ///
///                        -Jospeh Johnson Howland                            ///
///                                                                           ///
/////////////////////////////////////////////////////////////////////////////////



using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CsharpMapReduce
{
    class MappReducing
    {

        public static ConcurrentBag<string> wordBag = new ConcurrentBag<string>();
        public BlockingCollection<string> wordChunks = new BlockingCollection<string>(wordBag);
        //______________________________________________________________________________________________________________________________________________________________________________________________________
        public IEnumerable<String> produceWordBlocks(string fileText)       
        {
            int blockSize = fileText.Length/Environment.ProcessorCount; // adjusted to adapt to different machines
            int startPos = 0;
            int len = 0;

            for (int i = 0; i < fileText.Length; i++)
            {
                i = i + blockSize > fileText.Length - 1 ? fileText.Length - 1 : i + blockSize;

                while (i >= startPos && fileText[i] != ' ')
                {
                    i--;
                }                                                                                       // splits input into equal blocks for processing

                if (i == startPos)
                {
                    i = i + blockSize > (fileText.Length - 1) ? fileText.Length - 1 : i + blockSize;
                    len = (i - startPos) + 1;
                }
                else
                {
                    len = i - startPos;
                }

                yield return fileText.Substring(startPos, len).Trim();
                startPos = i;
            }
        }
        //___________________________________________________________________________________________________________________________________________________________________________________________________________

        public void mapWords(string fileText)
        {
            Parallel.ForEach(produceWordBlocks(fileText), wordBlock =>
            { 
                string[] words = wordBlock.Split(' ');
                StringBuilder wordBuffer = new StringBuilder();

                foreach (string word in words)                                                              // mapping func.  input -> blocks -> Mapped Data
                {   
                    foreach (char c in word)
                    {
                        if (char.IsLetterOrDigit(c) || c == '\'' || c == '-')
                            wordBuffer.Append(c);
                    }
                    if (wordBuffer.Length > 0)
                    {
                        wordChunks.Add(wordBuffer.ToString());
                        wordBuffer.Clear();
                    }
                }
            });

            wordChunks.CompleteAdding();
        }
        //___________________________________________________________________________________________________________________________________________________________________________________
        public ConcurrentDictionary<string, int> wordStore = new ConcurrentDictionary<string, int>();

        public void reduceWords()
        {
                                                                                                                                    //Reduce func.   Mapped data -> Tuple <String * int>
            Parallel.ForEach(wordChunks.GetConsumingEnumerable(), word =>
            {  
                wordStore.AddOrUpdate(word, 1, (key, oldValue) => Interlocked.Increment(ref oldValue));
            });
        }
        //_______________________________________________________________________________________________________________________________________________________________________
        public void mapReduce(string fileText)
        {                                                                                                           
            System.Diagnostics.Stopwatch stopwatch = new Stopwatch(); //Stopwatch for logger
            stopwatch.Start();

            if (wordChunks.IsAddingCompleted)
            {
                wordBag = new ConcurrentBag<string>();
                wordChunks = new BlockingCollection<string>(wordBag);
            }                                                                                   //full function  Input -> Mapper -> reducer -> Output

            System.Threading.ThreadPool.QueueUserWorkItem(delegate (object state)
            {
                mapWords(fileText);
            });

            reduceWords();
            stopwatch.Stop();
            //MappReducing.mapReduce(commandLog.Text);
            //___________________________________________________________________________________________________________________________________________________________________________
            StringBuilder sb = new StringBuilder();
            int totalWords = 10;
            foreach (KeyValuePair<string, int> kvp in wordStore)
            {
                
                sb.AppendLine(kvp.Key + ": " + kvp.Value);                  // added logging section
                totalWords += kvp.Value;

            }

            string hold = stopwatch.Elapsed.ToString();
            string ToWrite = hold + "\n";
            Console.WriteLine(sb.ToString());
            Console.WriteLine("Total Words: " + totalWords + "\r\n");
            Console.WriteLine("Time Elapsed(ms) : " + stopwatch.Elapsed);
            TextWriter tsw = new StreamWriter("..\\Times.txt", true);
            tsw.WriteLine(ToWrite);
            tsw.Close();

        }


    }
}
