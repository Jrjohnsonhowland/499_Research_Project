﻿
using System;
using System.IO;
using System.Text;



namespace MapReduceWords
{
    public class WordReducer
    {
        static void Main (string[] args)
        {

            string text = File.ReadAllText(@"..\\Frankenstein.txt", Encoding.UTF8);  // Edit directory here
            CsharpMapReduce.MappReducing Mapper = new CsharpMapReduce.MappReducing();

            Mapper.mapReduce(text);

            

        }


    }
}
